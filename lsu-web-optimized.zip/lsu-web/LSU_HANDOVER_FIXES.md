# LSU Handover Fixes — 2026-11-09

## Implemented
1. Pending Requests combines unverified `status: pending` registration records and unverified `verifyRequest.status: pending` records. This resolves the dashboard/list filter mismatch.
2. Public-facing directory data is read from sanitized `publicMembers` documents, not whole private `members` documents.
3. Public projection now includes `designation` for homepage President resolution.
4. Removed redundant initial member collection refresh and public-member listener from unrelated pages.
5. Added short in-page member cache reuse and in-flight request coalescing; admin mutations force a refresh.
6. Retain and display Firestore read/permission errors; failed data reads no longer look like a valid zero-member result.
7. Login form waits for Firebase auth initialization to avoid a sign-in form flash for restored sessions.
8. Generated local circular LSU logo and favicon/apple touch icon assets; replaced external logo references with local circular branding.
9. Existing Contact and Technology page requested content, F Combinator footer, and Gallery removal were already present and preserved.

## Deploy
- Publish the `lsu_project_updated` directory as the website root.
- Deploy Cloud Function changes: `cd functions && npm install && cd .. && firebase deploy --only functions`.
- Confirm current Firestore rules are deployed: `firebase deploy --only firestore:rules`.
- Run Admin Panel > Sync public directory/backfill if the existing `publicMembers` projection needs refresh (if that button is available in this build).
- Test verification after the Firestore daily read quota is available.

## Limitations
No production Firebase credentials, browser session, or live deployment access was available. Live verification, rules evaluation, and device testing remain deployment-side checks. No claim of deployment or live Firebase test is made.


## Final directory fix
- Members page now starts `refreshPublic()` and listens for `lsu:publicmemberschange`; it no longer renders a permanent empty cache.
- Members page distinguishes loading, Firestore errors, and a genuinely empty directory.
- Admin Panel now has a **Sync Public Directory** action that calls the protected `backfillPublicMembers` function.
- Backfill commits in chunks of 400 writes to stay below Firestore's 500-write batch limit.
- Public profile projection remains sanitized; no email, phone, address, or other private fields are copied to `publicMembers`.
