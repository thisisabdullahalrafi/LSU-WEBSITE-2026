# LSU ওয়েবসাইট — Final Production Deploy Guide (বাংলা)

## এই প্যাকেজে কী ঠিক করা হয়েছে

### মূল সমস্যা (Root Cause)
Members Directory, Executive Board এবং Homepage Statistics ০ দেখাচ্ছিল কারণ frontend `publicMembers` collection থেকে ডেটা পড়ছিল, কিন্তু সেই collection খালি ছিল (Cloud Functions deploy/backfill না হওয়ায়)।

### সমাধান
1. **Public directory এখন সরাসরি `members` collection থেকে verified + active সদস্য পড়ে** (Firestore Rules ইতিমধ্যেই এটাকে অনুমতি দেয়)।
2. Client-side sanitization করে email, phone, address ইত্যাদি private ফিল্ড public cache-এ ঢোকে না।
3. Homepage-এ এখন দেখায়:
   - Established
   - Registered members (শুধু Admin)
   - Verified members
   - Executive members
   - Upcoming events
4. Cloud Functions উন্নত করা হয়েছে — `publicMembers` sync + `meta/publicStats` অটো আপডেট।
5. Admin Panel-এর **Sync Public Directory** বোতাম আগের মতো কাজ করে (ঐচ্ছিক secondary path)।
6. Category / status / verified চেক আরও robust করা হয়েছে (case-insensitive)।

### Source of truth
- `members` = private master database (সব ফিল্ড)
- `publicMembers` = ঐচ্ছিক sanitized projection (Functions দিয়ে)
- `meta/publicStats` = public statistics (Functions দিয়ে)

Frontend এখন Functions ছাড়াই কাজ করবে। Functions deploy করলে secondary sync + stats document পাওয়া যাবে।

---

## Deploy ধাপসমূহ

### ১. ওয়েবসাইট (Netlify / Hosting)
1. এই ZIP extract করুন।
2. `lsu_project_updated` ফোল্ডারের ভিতরের **সব ফাইল** (index.html যেখানে আছে সেই লেভেল) Netlify-তে publish directory হিসেবে deploy করুন।
3. অথবা Firebase Hosting ব্যবহার করলে:

```bash
cd lsu_project_updated
firebase deploy --only hosting
```

### ২. Firestore Rules (অবশ্যই)

```bash
cd lsu_project_updated
firebase deploy --only firestore:rules,storage
```

Rules-এ verified + active members public read করা যায় — এটাই নতুন frontend query-এর ভিত্তি।

### ৩. Cloud Functions (ঐচ্ছিক কিন্তু সুপারিশকৃত)

```bash
cd lsu_project_updated
npm install --prefix functions
firebase deploy --only functions
```

**নোট:** Cloud Functions deploy করতে Firebase project-এ **Blaze (pay-as-you-go)** plan লাগতে পারে।

### ৪. পুরোনো Member Sync (ঐচ্ছিক)
Functions deploy করার পর:
1. Admin account দিয়ে login করুন।
2. Admin Panel → **Sync Public Directory** বোতামে ক্লিক করুন।
3. সফল হলে verifiedActive সংখ্যা দেখাবে।

Functions ছাড়াও Members Directory / Board / Stats এখন সরাসরি `members` থেকে কাজ করবে।

---

## Deploy পর Verification Checklist

1. [ ] Homepage-এ Verified members ও Executive members সংখ্যা ০-এর বেশি দেখাচ্ছে।
2. [ ] Members Directory (signed-in verified member দিয়ে) সদস্য কার্ড দেখাচ্ছে।
3. [ ] committee.html / Executive Board-এ Executive category-এর সদস্যরা তাদের position সহ দেখাচ্ছে।
4. [ ] Admin Panel-এ সব member দেখা যাচ্ছে এবং Verify / Unverify / Role change কাজ করছে।
5. [ ] কোনো member verify করার পর কয়েক সেকেন্ডের মধ্যে public pages আপডেট হচ্ছে (real-time listener)।
6. [ ] Public visitor email/phone দেখতে পাচ্ছে না (network tab চেক করলেও sanitized)।
7. [ ] Browser console-এ Firebase permission-denied error নেই।

---

## গুরুত্বপূর্ণ সতর্কতা
- Firebase project ID: `lsu-test` (config ও .firebaserc-এ)। অন্য প্রজেক্ট হলে দুটোই পরিবর্তন করুন।
- বিদ্যমান member document ID বা data মুছবেন না।
- Admin email: `support.eyms@gmail.com` bootstrap admin হিসেবে আছে।
- Executive Board-এর জন্য Admin Panel থেকে category = **Executive** এবং সঠিক role (President, General Secretary ইত্যাদি) সেট করুন।
- `status` ফিল্ড অবশ্যই `active` (lowercase) এবং `verified` অবশ্যই boolean `true` হতে হবে।

## সীমাবদ্ধতা
এই প্যাকেজে কোড-লেভেল syntax ও logic check করা হয়েছে। Live Firebase project বা deployed site-এ প্রবেশাধিকার না থাকায় live data verification এখান থেকে করা হয়নি। উপরের checklist দিয়ে আপনি নিজে verify করবেন।
