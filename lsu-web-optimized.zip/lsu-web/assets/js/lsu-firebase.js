/* LSU Firebase bridge — replaces localStorage auth with Firebase Auth + Firestore.
   Load after firebase-config.js, Firebase SDKs, lsu-data.js, and BEFORE lsu-core.js is ideal,
   but this file patches window.LSU after core if needed. Preferred load order is in HTML. */

(function () {
  'use strict';
  if (window.__LSU_FB_BRIDGE__) return;
  window.__LSU_FB_BRIDGE__ = true;

  var cfg = window.LSU_FIREBASE || {};
  var fbConfig = cfg.config || {};
  var adminEmails = (cfg.adminEmails || []).map(function (e) { return String(e).toLowerCase(); });

  function isConfigured() {
    return fbConfig.apiKey && fbConfig.apiKey !== 'YOUR_API_KEY' && fbConfig.projectId && fbConfig.projectId !== 'YOUR_PROJECT_ID';
  }

  if (!isConfigured()) {
    console.warn('[LSU Firebase] Not configured — edit assets/js/firebase-config.js');
    document.addEventListener('DOMContentLoaded', function () {
      if (document.getElementById('lsuConfigBanner')) return;
      var b = document.createElement('div');
      b.id = 'lsuConfigBanner';
      b.style.cssText = 'position:fixed;left:0;right:0;top:0;z-index:9999;background:#7a1f1a;color:#fff;padding:12px 16px;font:600 14px/1.45 system-ui,sans-serif;text-align:center';
      b.innerHTML = 'Firebase not configured. Edit <code style="background:rgba(255,255,255,.2);padding:2px 6px;border-radius:4px">assets/js/firebase-config.js</code> — see FIREBASE_SETUP.md';
      document.body.appendChild(b);
      document.body.style.paddingTop = '52px';
    });
    return;
  }

  if (typeof firebase === 'undefined') {
    console.error('[LSU Firebase] SDK missing');
    return;
  }

  // Clear legacy localStorage authentication state
  try {
    ['lsu.session', 'lsuLoggedIn', 'lsuCurrentMember', 'lsu.accounts', 'lsu.memberPatches'].forEach(function (k) {
      localStorage.removeItem(k);
      sessionStorage.removeItem(k);
    });
  } catch (e) {}

  if (!firebase.apps.length) firebase.initializeApp(fbConfig);
  var auth = firebase.auth();
  var db = firebase.firestore();
  var storage = null;
  try { storage = firebase.storage(); } catch (e) {}

  var currentMember = null;
  var authReady = false;
  var authLoadError = null;
  var membersCache = [];
  var publicMembersCache = [];
  var publicMembersLoadError = null;
  var publicMembersUnsubscribe = null;
  var eventsCache = [];
  var eventsLoadError = null;
  var eventsUnsubscribe = null;
  var membersFetchAt = 0;
  var membersFetchPromise = null;
  var membersLoadError = null;
  var EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

  function mapDoc(doc) {
    var d = doc.data() || {};
    d.id = d.id || doc.id;
    d.uid = d.uid || doc.id;
    return d;
  }

  function loadMember(uid) {
    return db.collection('members').doc(uid).get().then(function (snap) {
      if (!snap.exists) return null;
      var m = mapDoc(snap);
      return m;
    });
  }


  function sanitizePublicMember(raw) {
    if (!raw) return null;
    var status = String(raw.status || '').toLowerCase();
    var verified = raw.verified === true || raw.verified === 'true' || raw.verified === 1;
    if (!verified || status !== 'active') return null;
    var cat = String(raw.category || 'General Member').trim();
    if (cat === 'General') cat = 'General Member';
    return {
      uid: raw.uid || raw.id || '',
      id: raw.id || raw.uid || '',
      name: String(raw.name || ''),
      photo: String(raw.photo || ''),
      role: String(raw.role || raw.position || 'Member'),
      designation: String(raw.designation || ''),
      category: cat,
      memberId: String(raw.memberId || ''),
      batch: String(raw.batch || ''),
      profession: String(raw.profession || ''),
      org: String(raw.org || ''),
      verified: true,
      status: 'active'
      // Intentionally omit email, phone, address, admin, verifyRequest, etc.
    };
  }

  function refreshPublicMembers() {
    // Query verified+active members directly from the private collection.
    // Firestore rules already permit public reads of those documents.
    // Client-side sanitization strips private fields before they enter the cache
    // used by the Members Directory, Executive Board and homepage.
    // The optional publicMembers projection + Cloud Functions remain available
    // as a secondary sync path (Admin "Sync Public Directory").
    if (publicMembersUnsubscribe) return Promise.resolve(publicMembersCache);
    return new Promise(function (resolve) {
      function applySnap(snap) {
        publicMembersLoadError = null;
        publicMembersCache = [];
        snap.forEach(function (doc) {
          var m = sanitizePublicMember(mapDoc(doc));
          if (m) publicMembersCache.push(m);
        });
        document.dispatchEvent(new CustomEvent('lsu:publicmemberschange'));
        resolve(publicMembersCache);
      }
      function onErr(err) {
        console.warn('[LSU] public member listener failed:', err && err.message);
        publicMembersLoadError = err && err.code === 'resource-exhausted'
          ? 'Firestore read quota exceeded; public member data is temporarily unavailable.'
          : err && err.code === 'permission-denied'
            ? 'Public member data is blocked by Firestore rules. Deploy the current firestore.rules.'
            : (err && err.message) || 'Public member data could not be loaded.';
        publicMembersUnsubscribe = null;
        resolve(publicMembersCache);
      }
      try {
        publicMembersUnsubscribe = db.collection('members')
          .where('verified', '==', true)
          .where('status', '==', 'active')
          .onSnapshot(applySnap, onErr);
      } catch (e) {
        onErr(e);
      }
    });
  }

  function refreshMembers(force) {
    // Avoid duplicate collection reads during the same page/auth initialization.
    // Mutating admin operations call this with force=true after a successful write.
    if (!currentMember) { membersCache = []; return Promise.resolve(membersCache); }
    if (!currentMember.admin && (currentMember.verified !== true || currentMember.status !== 'active')) {
      membersCache = [currentMember];
      return Promise.resolve(membersCache);
    }
    var now = Date.now();
    if (!force && membersFetchPromise) return membersFetchPromise;
    if (!force && membersFetchAt && now - membersFetchAt < 15000) return Promise.resolve(membersCache);
    var query = currentMember.admin
      ? db.collection('members')
      : db.collection('members').where('verified', '==', true).where('status', '==', 'active');
    membersFetchPromise = query.get().then(function (snap) {
      membersCache = [];
      snap.forEach(function (doc) { membersCache.push(mapDoc(doc)); });
      membersLoadError = null;
      membersFetchAt = Date.now();
      return membersCache;
    }).catch(function (err) {
      console.warn('[LSU] Could not refresh member directory:', err);
      membersLoadError = err && err.code === 'resource-exhausted'
        ? 'Firestore read quota exceeded. Member data could not be refreshed; wait for quota reset or upgrade billing.'
        : err && err.code === 'permission-denied'
          ? 'Firestore denied the member query. Check deployed security rules and administrator access.'
          : (err && err.message) || 'Member data could not be refreshed.';
      // Keep the last known cache; a read failure must not sign the user out
      // or masquerade as a successful empty list.
      return membersCache;
    }).then(function (result) {
      membersFetchPromise = null; return result;
    }, function (err) { membersFetchPromise = null; throw err; });
    return membersFetchPromise;
  }

  function authError(code) {
    var map = {
      'auth/invalid-email': 'Enter a valid email address.',
      'auth/user-disabled': 'This account has been disabled.',
      'auth/user-not-found': 'Incorrect email or password.',
      'auth/wrong-password': 'Incorrect email or password.',
      'auth/invalid-credential': 'Incorrect email or password.',
      'auth/email-already-in-use': 'An account with this email already exists.',
      'auth/weak-password': 'Password is too weak.',
      'auth/too-many-requests': 'Too many attempts. Try again later.',
      'auth/network-request-failed': 'Network error. Check your connection.',
      'auth/operation-not-allowed': 'Enable Email/Password in Firebase Console → Authentication.'
    };
    return map[code] || 'Something went wrong. Please try again.';
  }

  function refreshEvents() {
    if (eventsUnsubscribe) return Promise.resolve(eventsCache);
    return new Promise(function (resolve) {
      function applySnap(snap) {
        eventsLoadError = null;
        eventsCache = [];
        snap.forEach(function (doc) {
          var d = doc.data() || {};
          d.id = doc.id;
          eventsCache.push(d);
        });
        // Keep legacy L.data.EVENTS in sync for older UI paths
        if (window.LSU && window.LSU.data) window.LSU.data.EVENTS = eventsCache.slice();
        document.dispatchEvent(new CustomEvent('lsu:eventschange'));
        resolve(eventsCache);
      }
      function onErr(err) {
        console.warn('[LSU] events listener failed:', err && err.message);
        eventsLoadError = (err && err.message) || 'Events could not be loaded.';
        eventsUnsubscribe = null;
        resolve(eventsCache);
      }
      try {
        eventsUnsubscribe = db.collection('events').onSnapshot(applySnap, onErr);
      } catch (e) { onErr(e); }
    });
  }

  function requireAdminForEvents() {
    return currentMember && currentMember.admin ? currentMember : null;
  }

  function applyApi(L) {
    if (!L) return;

    L.members.all = function () { return membersCache.slice(); };
    L.members.publicAll = function () { return publicMembersCache.slice(); };
    L.members.publicLoadError = function () { return publicMembersLoadError; };
    L.members.refreshPublic = refreshPublicMembers;
    L.members.find = function (id) {
      for (var i = 0; i < membersCache.length; i++) {
        var m = membersCache[i];
        if (m.id === id || m.uid === id || m.memberId === id) return m;
      }
      return null;
    };
    L.members.refresh = refreshMembers;
    L.members.loadError = function () { return membersLoadError; };

    L.events = L.events || {};
    L.events.all = function () { return eventsCache.slice(); };
    L.events.find = function (id) {
      for (var i = 0; i < eventsCache.length; i++) if (eventsCache[i].id === id) return eventsCache[i];
      return null;
    };
    L.events.loadError = function () { return eventsLoadError; };
    L.events.refresh = refreshEvents;
    L.events.create = function (payload) {
      if (!requireAdminForEvents()) return Promise.resolve({ ok: false, error: 'Admin access required.' });
      var title = String(payload.title || '').trim();
      var date = String(payload.date || '').trim();
      var time = String(payload.time || '').trim();
      var description = String(payload.description || '').trim();
      var registrationLink = String(payload.registrationLink || '').trim();
      var status = String(payload.status || 'upcoming').trim().toLowerCase();
      if (!title || !date) return Promise.resolve({ ok: false, error: 'Title and date are required.' });
      if (['upcoming', 'pending', 'ended'].indexOf(status) < 0) status = 'upcoming';
      var doc = {
        title: title.slice(0, 120),
        date: date,
        time: time.slice(0, 20),
        description: description.slice(0, 800),
        registrationLink: registrationLink.slice(0, 400),
        status: status,
        createdAt: firebase.firestore.FieldValue.serverTimestamp(),
        updatedAt: firebase.firestore.FieldValue.serverTimestamp(),
        createdBy: currentMember.uid
      };
      return db.collection('events').add(doc).then(function () {
        return { ok: true };
      }).catch(function (err) { return { ok: false, error: err.message || 'Could not create event.' }; });
    };
    L.events.update = function (id, payload) {
      if (!requireAdminForEvents()) return Promise.resolve({ ok: false, error: 'Admin access required.' });
      if (!id) return Promise.resolve({ ok: false, error: 'Missing event id.' });
      var clean = { updatedAt: firebase.firestore.FieldValue.serverTimestamp() };
      if (payload.title !== undefined) clean.title = String(payload.title || '').trim().slice(0, 120);
      if (payload.date !== undefined) clean.date = String(payload.date || '').trim();
      if (payload.time !== undefined) clean.time = String(payload.time || '').trim().slice(0, 20);
      if (payload.description !== undefined) clean.description = String(payload.description || '').trim().slice(0, 800);
      if (payload.registrationLink !== undefined) clean.registrationLink = String(payload.registrationLink || '').trim().slice(0, 400);
      if (payload.status !== undefined) {
        var st = String(payload.status || 'upcoming').trim().toLowerCase();
        if (['upcoming', 'pending', 'ended'].indexOf(st) < 0) st = 'upcoming';
        clean.status = st;
      }
      if (!clean.title && payload.title !== undefined) return Promise.resolve({ ok: false, error: 'Title is required.' });
      if (!clean.date && payload.date !== undefined) return Promise.resolve({ ok: false, error: 'Date is required.' });
      return db.collection('events').doc(id).update(clean).then(function () {
        return { ok: true };
      }).catch(function (err) { return { ok: false, error: err.message || 'Could not update event.' }; });
    };
    L.events.remove = function (id) {
      if (!requireAdminForEvents()) return Promise.resolve({ ok: false, error: 'Admin access required.' });
      if (!id) return Promise.resolve({ ok: false, error: 'Missing event id.' });
      return db.collection('events').doc(id).delete().then(function () {
        return { ok: true };
      }).catch(function (err) { return { ok: false, error: err.message || 'Could not delete event.' }; });
    };

    L.auth.current = function () { return currentMember; };
    L.auth.isReady = function () { return authReady; };
    L.auth.loadError = function () { return authLoadError; };
    L.auth.isAdmin = function (u) { return !!(u && u.admin === true); };

    L.auth.login = function (identifier, password, remember) {
      var id = String(identifier || '').trim();
      var persist = remember === false
        ? firebase.auth.Auth.Persistence.SESSION
        : firebase.auth.Auth.Persistence.LOCAL;

      return auth.setPersistence(persist).then(function () {
        if (id.indexOf('@') === -1) {
          return db.collection('members').where('memberId', '==', id).limit(1).get().then(function (snap) {
            if (snap.empty) return Promise.reject({ code: 'auth/user-not-found' });
            var email = snap.docs[0].data().email;
            if (!email) return Promise.reject({ code: 'auth/user-not-found' });
            return auth.signInWithEmailAndPassword(email, password);
          });
        }
        return auth.signInWithEmailAndPassword(id.toLowerCase(), password);
      }).then(function (cred) {
        var uid = cred.user.uid;
        var authEmail = String(cred.user.email || '').toLowerCase();
        return loadMember(uid).then(function (m) {
          // Auto-heal: Auth exists but Firestore profile missing
          if (!m) {
            var isAdm = adminEmails.indexOf(authEmail) >= 0;
            var member = {
              uid: uid, id: uid, memberId: isAdm ? 'LSU-ADMIN-001' : '',
              name: (cred.user.displayName || authEmail.split('@')[0] || 'Member'),
              email: authEmail, phone: '', batch: '', gender: '',
              role: 'Member', category: 'General Member',
              verified: false, status: 'active', admin: false,
              photo: '', bio: '', profession: '', org: '', designation: '',
              createdAt: firebase.firestore.FieldValue.serverTimestamp()
            };
            return db.collection('members').doc(uid).set(member).then(function () {
              if (isAdm) return db.collection('members').doc(uid).update({ admin: true, status: 'active' });
            }).then(function () {
              member.admin = isAdm;
              currentMember = member;
              return refreshMembers().then(function () {
                document.dispatchEvent(new CustomEvent('lsu:authchange'));
                return { ok: true, user: member };
              });
            });
          }
          if (m.status === 'rejected' || m.status === 'suspended') {
            return { ok: false, error: 'This account is not active. Please contact LSU.' };
          }
          var email = String(m.email || authEmail).toLowerCase();
          if (adminEmails.indexOf(email) >= 0 && !m.admin) {
            return db.collection('members').doc(m.uid).update({ admin: true, status: 'active' }).then(function () {
              m.admin = true; m.status = 'active';
              currentMember = m;
              return refreshMembers().then(function () {
                document.dispatchEvent(new CustomEvent('lsu:authchange'));
                return { ok: true, user: m };
              });
            });
          }
          currentMember = m;
          return refreshMembers().then(function () {
            document.dispatchEvent(new CustomEvent('lsu:authchange'));
            return { ok: true, user: m };
          });
        });
      }).catch(function (err) {
        return { ok: false, error: authError(err.code) || (err.message || 'Sign in failed.') };
      });
    };

    L.auth.register = function (d) {
      var email = String(d.email || '').trim().toLowerCase();
      var name = String(d.name || '').trim();
      if (!EMAIL_RE.test(email)) return Promise.resolve({ ok: false, field: 'email', error: 'Enter a valid email address.' });
      if (!name) return Promise.resolve({ ok: false, field: 'name', error: 'Enter your full name.' });
      if (!L.auth.strongPassword(d.password)) return Promise.resolve({ ok: false, field: 'password', error: 'Use at least 8 characters with a letter and a number.' });
      var isAdminEmail = adminEmails.indexOf(email) >= 0;

      return auth.createUserWithEmailAndPassword(email, d.password).then(function (cred) {
        var uid = cred.user.uid;
        // Always create admin:false (Firestore rules). Login promotes adminEmails.
        var member = {
          uid: uid, id: uid, memberId: '', name: name, email: email,
          phone: String(d.phone || '').trim(), batch: String(d.batch || '').trim(), gender: d.gender || '',
          role: 'Member', category: 'General Member', verified: false,
          status: isAdminEmail ? 'active' : 'pending', admin: false,
          createdAt: firebase.firestore.FieldValue.serverTimestamp(),
          photo: '', bio: '', profession: '', org: '', designation: ''
        };
        return db.collection('members').doc(uid).set(member).then(function () {
          currentMember = member;
          return refreshMembers().then(function () {
            document.dispatchEvent(new CustomEvent('lsu:authchange'));
            return { ok: true, user: member };
          });
        });
      }).catch(function (err) {
        return { ok: false, field: err.code === 'auth/email-already-in-use' ? 'email' : null, error: authError(err.code) };
      });
    };

    L.auth.logout = function (redirect) {
      return auth.signOut().then(function () {
        currentMember = null;
        document.dispatchEvent(new CustomEvent('lsu:authchange'));
        if (redirect) window.location.href = redirect;
      });
    };

    L.auth.requestPasswordReset = function (email) {
      var e = String(email || '').trim().toLowerCase();
      if (!EMAIL_RE.test(e)) return Promise.resolve({ ok: false, error: 'Enter a valid email address.' });
      return auth.sendPasswordResetEmail(e).then(function () {
        return { ok: true, message: 'If an account exists for that email, a password reset link has been sent.' };
      }).catch(function (err) {
        if (err.code === 'auth/user-not-found') {
          return { ok: true, message: 'If an account exists for that email, a password reset link has been sent.' };
        }
        return { ok: false, error: authError(err.code) };
      });
    };

    L.auth.changePassword = function (currentPass, newPass) {
      var user = auth.currentUser;
      if (!user || !user.email) return Promise.resolve({ ok: false, error: 'Not signed in.' });
      if (!L.auth.strongPassword(newPass)) return Promise.resolve({ ok: false, error: 'New password must be at least 8 characters with a letter and a number.' });
      var cred = firebase.auth.EmailAuthProvider.credential(user.email, currentPass);
      return user.reauthenticateWithCredential(cred).then(function () {
        return user.updatePassword(newPass);
      }).then(function () { return { ok: true }; })
        .catch(function (err) {
          if (err.code === 'auth/wrong-password' || err.code === 'auth/invalid-credential') {
            return { ok: false, error: 'Current password is incorrect.' };
          }
          return { ok: false, error: authError(err.code) };
        });
    };

    var OWN = ['name', 'gender', 'dob', 'location', 'phone', 'address', 'bio', 'profession', 'org', 'designation', 'skills', 'interests',
      'facebook', 'linkedin', 'website', 'batch', 'sscInstitution', 'hscInstitution', 'hsc', 'university', 'subject', 'bachelor', 'master', 'photo'];

    L.profile.updateOwn = function (patch) {
      var u = currentMember;
      if (!u || !auth.currentUser) return Promise.resolve({ ok: false, error: 'Not signed in.' });
      var clean = {};
      OWN.forEach(function (k) { if (Object.prototype.hasOwnProperty.call(patch, k)) clean[k] = patch[k]; });
      if (clean.name !== undefined && !String(clean.name).trim()) return Promise.resolve({ ok: false, error: 'Name cannot be empty.' });
      clean.updatedAt = firebase.firestore.FieldValue.serverTimestamp();
      return db.collection('members').doc(u.uid).update(clean).then(function () {
        return loadMember(u.uid).then(function (m) {
          currentMember = m;
          return refreshMembers().then(function () {
            document.dispatchEvent(new CustomEvent('lsu:authchange'));
            return { ok: true, user: m };
          });
        });
      }).catch(function (err) { return { ok: false, error: err.message || 'Could not save.' }; });
    };

    L.profile.requestVerification = function () {
      var u = currentMember;
      if (!u || u.verified) return Promise.resolve({ ok: false });
      var req = { status: 'pending', at: new Date().toISOString() };
      return db.collection('members').doc(u.uid).update({ verifyRequest: req }).then(function () {
        return loadMember(u.uid).then(function (m) {
          currentMember = m;
          document.dispatchEvent(new CustomEvent('lsu:authchange'));
          return { ok: true, user: m };
        });
      });
    };

    function requireAdmin() {
      return currentMember && currentMember.admin ? currentMember : null;
    }

    L.admin.setVerified = function (id, verified) {
      if (!requireAdmin()) return Promise.resolve({ ok: false, error: 'Admin access required.' });
      var m = L.members.find(id);
      if (!m) return Promise.resolve({ ok: false, error: 'Member not found.' });
      var memberRef = db.collection('members').doc(m.uid || m.id);
      if (!verified) {
        return memberRef.update({ verified: false }).then(function () {
          return refreshMembers(true).then(function () {
            document.dispatchEvent(new CustomEvent('lsu:authchange'));
            return { ok: true, user: L.members.find(id) };
          });
        }).catch(function (err) { return { ok: false, error: err.message || 'Could not update verification.' }; });
      }
      var counterRef = db.collection('meta').doc('memberSerial');
      var cachedMax = membersCache.reduce(function (max, item) { var n = parseInt(item.memberId, 10); return isFinite(n) && n > max ? n : max; }, 1000);
      return db.runTransaction(function (tx) {
        return tx.get(memberRef).then(function (memberSnap) {
          if (!memberSnap.exists) throw new Error('Member not found.');
          var data = memberSnap.data() || {};
          var existing = String(data.memberId || '');
          if (/^\d+$/.test(existing)) {
            tx.update(memberRef, { verified: true, status: 'active', verifyRequest: firebase.firestore.FieldValue.delete() });
            return existing;
          }
          return tx.get(counterRef).then(function (counterSnap) {
            var last = counterSnap.exists ? Number(counterSnap.data().lastIssued || 1000) : 1000;
            if (!isFinite(last) || last < 1000) last = 1000;
            var next = Math.max(Math.floor(last), cachedMax) + 1;
            tx.set(counterRef, { lastIssued: next }, { merge: true });
            tx.update(memberRef, { memberId: String(next), verified: true, status: 'active', verifyRequest: firebase.firestore.FieldValue.delete() });
            return String(next);
          });
        });
      }).then(function () {
        return refreshMembers(true).then(function () {
          document.dispatchEvent(new CustomEvent('lsu:authchange'));
          return { ok: true, user: L.members.find(id) };
        });
      }).catch(function (err) { return { ok: false, error: err.message || 'Could not verify member.' }; });
    };

    L.admin.setRole = function (id, role, category) {
      if (!requireAdmin()) return Promise.resolve({ ok: false, error: 'Admin access required.' });
      var m = L.members.find(id);
      var cleanRole = String(role || '').trim().replace(/\s+/g, ' ');
      if (!m) return Promise.resolve({ ok: false, error: 'Member not found.' });
      if (!cleanRole || cleanRole.length > 80) return Promise.resolve({ ok: false, error: 'Enter a position between 1 and 80 characters.' });
      var cleanCategory = String(category || m.category || 'General Member').trim();
      if (['General', 'General Member', 'Executive', 'Alumni'].indexOf(cleanCategory) < 0) return Promise.resolve({ ok: false, error: 'Invalid member category.' });
      return db.collection('members').doc(m.uid || m.id).update({ role: cleanRole, category: cleanCategory }).then(function () {
        if (currentMember && (currentMember.uid === m.uid || currentMember.id === m.id)) { currentMember.role = cleanRole; currentMember.category = cleanCategory; }
        return refreshMembers(true).then(function () {
          document.dispatchEvent(new CustomEvent('lsu:authchange'));
          return { ok: true, user: L.members.find(id) };
        });
      }).catch(function (err) { return { ok: false, error: err.message || 'Could not update position.' }; });
    };

    L.admin.setStatus = function (id, status) {
      if (!requireAdmin()) return Promise.resolve({ ok: false, error: 'Admin access required.' });
      var m = L.members.find(id);
      if (!m) return Promise.resolve({ ok: false, error: 'Member not found.' });
      return db.collection('members').doc(m.uid || m.id).update({ status: status }).then(function () {
        return refreshMembers(true).then(function () {
          document.dispatchEvent(new CustomEvent('lsu:authchange'));
          return { ok: true, user: L.members.find(id) };
        });
      }).catch(function (err) { return { ok: false, error: err.message }; });
    };

    L.admin.approve = function (id) {
      if (!requireAdmin()) return Promise.resolve({ ok: false, error: 'Admin access required.' });
      var m = L.members.find(id);
      if (!m) return Promise.resolve({ ok: false, error: 'Member not found.' });
      return db.collection('members').doc(m.uid || m.id).update({ status: 'active' }).then(function () {
        return refreshMembers(true).then(function () {
          document.dispatchEvent(new CustomEvent('lsu:authchange'));
          return { ok: true, user: L.members.find(id) };
        });
      }).catch(function (err) { return { ok: false, error: err.message }; });
    };

    L.admin.updateMember = function (id, patch) {
      if (!requireAdmin()) return Promise.resolve({ ok: false, error: 'Admin access required.' });
      var m = L.members.find(id);
      if (!m) return Promise.resolve({ ok: false, error: 'Member not found.' });
      var allowed = ['name', 'designation', 'profession', 'org', 'phone', 'batch'];
      var clean = {};
      allowed.forEach(function (key) { if (Object.prototype.hasOwnProperty.call(patch || {}, key)) clean[key] = String(patch[key] || '').trim().slice(0, 160); });
      if (clean.name !== undefined && !clean.name) return Promise.resolve({ ok: false, error: 'Name cannot be empty.' });
      return db.collection('members').doc(m.uid || m.id).update(clean).then(function () {
        return refreshMembers(true).then(function () { document.dispatchEvent(new CustomEvent('lsu:authchange')); return { ok: true, user: L.members.find(id) }; });
      }).catch(function (err) { return { ok: false, error: err.message || 'Could not update member.' }; });
    };

    L.admin.reject = function (id) { return L.admin.setStatus(id, 'rejected'); };

    L.admin.removeMember = function (id) {
      if (!requireAdmin()) return Promise.resolve({ ok: false, error: 'Admin access required.' });
      var m = L.members.find(id);
      if (!m) return Promise.resolve({ ok: false, error: 'Member not found.' });
      var uid = m.uid || m.id;
      return db.collection('members').doc(uid).delete().then(function () {
        return db.collection('publicMembers').doc(uid).delete().catch(function () {}).then(function () {
          return refreshMembers(true).then(function () {
            document.dispatchEvent(new CustomEvent('lsu:authchange'));
            if (L.members.refreshPublic) L.members.refreshPublic();
            return { ok: true };
          });
        });
      }).catch(function (err) { return { ok: false, error: err.message || 'Could not delete member.' }; });
    };


    L.firebaseConfigured = function () { return true; };
  }

  function startAuthListener() {
    auth.onAuthStateChanged(function (user) {
      authReady = false;
      authLoadError = null;
      if (!user) {
        currentMember = null;
        authReady = true;
        document.dispatchEvent(new CustomEvent('lsu:authchange'));
        return;
      }
      var uid = user.uid;
      var email = String(user.email || '').trim().toLowerCase();
      var isBootstrapAdmin = adminEmails.indexOf(email) !== -1;
      loadMember(uid).then(function (member) {
        // Restore older Firebase Auth accounts that do not yet have a Firestore profile.
        if (!member) {
          member = {
            uid: uid, id: uid, memberId: isBootstrapAdmin ? 'LSU-ADMIN-001' : '',
            name: user.displayName || (email ? email.split('@')[0] : 'LSU Member'),
            email: email, phone: '', batch: '', gender: '', role: 'Member',
            category: 'General Member', verified: false,
            status: isBootstrapAdmin ? 'active' : 'pending', admin: false,
            photo: user.photoURL || '', bio: '', profession: '', org: '', designation: '',
            createdAt: firebase.firestore.FieldValue.serverTimestamp()
          };
          return db.collection('members').doc(uid).set(member).then(function () { return member; });
        }
        return member;
      }).then(function (member) {
        if (!member) throw new Error('Your member profile could not be loaded.');
        if (member.status === 'rejected' || member.status === 'suspended') {
          currentMember = null;
          authLoadError = 'This account is not active. Please contact LSU.';
          return null;
        }
        // Only the configured bootstrap email can self-promote; Firestore Rules enforce it too.
        if (isBootstrapAdmin && member.admin !== true) {
          return db.collection('members').doc(uid).update({ admin: true, status: 'active' }).then(function () {
            member.admin = true; member.status = 'active'; return member;
          });
        }
        return member;
      }).then(function (member) {
        currentMember = member || null;
        return refreshMembers();
      }).then(function () {
        authReady = true;
        document.dispatchEvent(new CustomEvent('lsu:authchange'));
      }).catch(function (err) {
        currentMember = null;
        authLoadError = err && err.code === 'permission-denied'
          ? 'Your account is signed in, but Firestore access is blocked. Publish the current Firestore Rules and try again.'
          : 'We could not load your LSU profile. Please refresh the page or contact an administrator.';
        authReady = true;
        console.error('[LSU Firebase] Could not restore signed-in profile:', err);
        document.dispatchEvent(new CustomEvent('lsu:authchange'));
      });
    });
  }

  function boot() {
    function go() {
      if (!window.LSU) return false;
      applyApi(window.LSU);
      startAuthListener();
      refreshEvents();
      // Initial member cache is loaded by startAuthListener after the profile
      // resolves. Avoid a second collection read on every page boot.
      return true;
    }
    if (!go()) {
      document.addEventListener('lsu:ready', function () { go(); }, { once: true });
    }
  }

  boot();
})();
