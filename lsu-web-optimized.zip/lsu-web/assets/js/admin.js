/* Admin panel — private. Only accounts with admin:true can access. */
(function () {
  'use strict';
  function start() {
    var L = window.LSU, $ = L.$, esc = L.esc;
    var root = $('#adminRoot');
    var tab = 'verified';
    var detailId = null;
    function executiveRoles() {
      return [
        'President',
        'Senior Vice President',
        'Vice President',
        'General Secretary',
        'Joint Secretary',
        'Treasurer',
        'Administrative Secretary',
        'Planning & Strategy Secretary',
        'Organizing Secretary',
        'Office Secretary',
        'Member Development Secretary',
        'Cultural Secretary',
        'Assistant Cultural Secretary',
        'Event Coordinator',
        'Assistant Event Coordinator',
        'Public Relations Head',
        'Assistant Public Relations Head',
        'Academic Coordinator',
        'Assistant Academic Coordinator',
        'Publication Head',
        'Assistant Publication Head',
        'IT Coordinator',
        'Assistant IT Coordinator',
        'Sports Secretary',
        'Assistant Sports Secretary',
        'Research & Analysis Coordinator',
        'Asst. Research & Analysis Coordinator',
        'Legal Affairs & Policy Coordinator',
        'Asst. Legal Affairs & Policy Coordinator',
        'Alumni Coordinator',
        'Assistant Alumni Coordinator',
        'Women Affairs Secretary',
        'Assistant Women Affairs Secretary',
        'Career Development Secretary',
        'Asst. Career Development Secretary',
        'Partnership & Outreach Secretary',
        'Asst. Partnership & Outreach Secretary',
        'Volunteer Coordinator',
        'Assistant Volunteer Coordinator',
        'Blood Donation Coordinator',
        'Asst. Blood Donation Coordinator',
        'Local Development Coordinator',
        'Asst. Local Development Coordinator',
        'Member',
        'Other (type below)'
      ];
    }
    function optionList(values, selected) {
      return values.map(function (v) { return '<option value="' + esc(v) + '"' + (v === selected ? ' selected' : '') + '>' + esc(v) + '</option>'; }).join('');
    }
    function roleSelectHtml(currentRole) {
      var roles = executiveRoles();
      var known = roles.indexOf(currentRole) >= 0 && currentRole !== 'Other (type below)';
      var selected = known ? currentRole : (currentRole && currentRole !== 'Member' ? 'Other (type below)' : 'Member');
      var customVal = known || !currentRole || currentRole === 'Member' ? '' : currentRole;
      return '<label for="adminRoleSelect">Executive Board role</label>' +
        '<div class="admin-role-row">' +
        '<select class="input" id="adminRoleSelect">' + optionList(roles, selected) + '</select>' +
        '</div>' +
        '<label for="adminRoleCustom" id="adminRoleCustomLabel"' + (selected === 'Other (type below)' ? '' : ' style="display:none"') + '>Custom role (type here)</label>' +
        '<div class="admin-role-row" id="adminRoleCustomWrap"' + (selected === 'Other (type below)' ? '' : ' style="display:none"') + '>' +
        '<input class="input" id="adminRoleCustom" maxlength="80" placeholder="Type position name…" value="' + esc(customVal) + '">' +
        '</div>';
    }

    function gate() {
      document.title = 'Admin access required — LSU';
      root.innerHTML = '<section class="card admin-gate">' +
        '<img class="avatar" src="' + L.guestAvatar() + '" alt="" width="84" height="84">' +
        '<h1>Admin access required</h1>' +
        '<p>This area is restricted to LSU administrators. Sign in with an admin account to manage members and verification.</p>' +
        '<div class="gate-actions" style="display:flex;gap:10px;justify-content:center;flex-wrap:wrap">' +
        '<a class="btn btn-primary" href="' + L.loginUrl('admin.html') + '">Sign In</a>' +
        '<a class="btn btn-outline" href="index.html">Back to Home</a></div></section>';
    }

    function stats(all) {
      var verified = all.filter(function (m) { return m.verified === true; }).length;
      var requested = all.filter(function (m) {
        return m.verified !== true && (
          m.status === 'pending' ||
          (m.verifyRequest && m.verifyRequest.status === 'pending')
        );
      }).length;
      var notVerified = all.filter(function (m) {
        var s = String(m.status || '').toLowerCase();
        return m.verified !== true && s !== 'suspended' && s !== 'rejected';
      }).length;
      var suspended = all.filter(function (m) {
        var s = String(m.status || '').toLowerCase();
        return s === 'suspended' || s === 'rejected';
      }).length;
      return [
        [verified, 'Verified members'],
        [requested, 'Requested'],
        [notVerified, 'Not verified'],
        [suspended, 'Suspended']
      ];
    }

    function statusPill(m) {
      var s = m.status || (m.verified ? 'active' : 'pending');
      return '<span class="status-pill status-' + esc(s) + '">' + esc(s) + '</span>';
    }

    function rowActions(m) {
      var btns = [];
      if (m.status === 'pending') {
        btns.push('<button type="button" class="btn btn-primary btn-sm" data-act="approve" data-id="' + esc(m.id) + '">Approve</button>');
        btns.push('<button type="button" class="btn btn-outline btn-sm" data-act="reject" data-id="' + esc(m.id) + '">Reject</button>');
      }
      if (!m.verified) {
        btns.push('<button type="button" class="btn btn-accent btn-sm" data-act="verify" data-id="' + esc(m.id) + '">Verify</button>');
      } else {
        btns.push('<button type="button" class="btn btn-outline btn-sm" data-act="unverify" data-id="' + esc(m.id) + '">Unverify</button>');
      }
      btns.push('<button type="button" class="btn btn-ghost btn-sm" data-act="detail" data-id="' + esc(m.id) + '">Details</button>');
      btns.push('<button type="button" class="btn btn-outline btn-sm" data-act="delete-member" data-id="' + esc(m.id) + '">Delete</button>');
      return '<div class="admin-actions">' + btns.join('') + '</div>';
    }

    function table(list) {
      if (!list.length) return '<div class="admin-empty">No members in this list.</div>';
      return '<div class="admin-table-wrap"><table class="admin-table"><thead><tr>' +
        '<th>Member / ID</th><th>Status</th><th>Verified</th><th>Role</th><th>Actions</th></tr></thead><tbody>' +
        list.map(function (m) {
          return '<tr><td><div class="name-cell"><img src="' + (m.photo || L.avatar(m.name)) + '" alt="">' +
            '<div><strong>' + esc(m.name) + (m.verified ? ' ' + L.verifiedBadge() : '') + '</strong>' +
            '<small>' + esc(m.email || '') + ' · ' + esc(L.profile.memberIdLabel(m)) + '</small></div></div></td>' +
            '<td>' + statusPill(m) + '</td>' +
            '<td>' + (m.verified ? 'Yes' : 'No') + '</td>' +
            '<td>' + esc(m.role || 'Member') + '</td>' +
            '<td>' + rowActions(m) + '</td></tr>';
        }).join('') + '</tbody></table></div>';
    }

    function eventsPanel() {
      var events = (L.events && L.events.all) ? L.events.all() : [];
      events = events.slice().sort(function (a, b) {
        var ad = String(a.date || ''), bd = String(b.date || '');
        return bd.localeCompare(ad) || String(a.title || '').localeCompare(String(b.title || ''));
      });
      function autoStatus(dateStr) {
        if (!dateStr) return 'upcoming';
        var today = new Date();
        today.setHours(0,0,0,0);
        var d = new Date(dateStr + 'T00:00:00');
        if (isNaN(d.getTime())) return 'upcoming';
        d.setHours(0,0,0,0);
        var diff = d.getTime() - today.getTime();
        if (diff < 0) return 'ended';
        if (diff === 0) return 'pending';
        return 'upcoming';
      }
      var rows = events.length ? events.map(function (e) {
        var st = e.status || autoStatus(e.date);
        return '<tr><td><strong>' + esc(e.title || '') + '</strong><br><small>' + esc(e.description || '').slice(0, 120) + '</small></td>' +
          '<td>' + esc(e.date || '—') + (e.time ? '<br><small>' + esc(e.time) + '</small>' : '') + '</td>' +
          '<td><span class="status-pill status-' + esc(st) + '">' + esc(st) + '</span></td>' +
          '<td><div class="admin-actions">' +
          '<button type="button" class="btn btn-ghost btn-sm" data-act="event-edit" data-id="' + esc(e.id) + '">Edit</button>' +
          '<button type="button" class="btn btn-outline btn-sm" data-act="event-delete" data-id="' + esc(e.id) + '">Delete</button>' +
          '</div></td></tr>';
      }).join('') : '<tr><td colspan="4" class="admin-empty">No events yet. Click “Add Event” to create one.</td></tr>';
      return '<div class="admin-events">' +
        '<div style="display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap;margin-bottom:14px">' +
        '<h3 style="margin:0">Events</h3>' +
        '<button type="button" class="btn btn-primary btn-sm" data-act="event-show-form">Add Event</button>' +
        '</div>' +
        '<div class="admin-role-editor" id="eventFormWrap" style="display:none">' +
        '<h3 id="eventFormTitle">Add Event</h3>' +
        '<div class="form-grid">' +
        '<label>Title<input class="input" id="evTitle" maxlength="120" placeholder="Event title"></label>' +
        '<label>Date<input class="input" id="evDate" type="date"></label>' +
        '<label>Time<input class="input" id="evTime" type="time"></label>' +
        '<label>Status<select class="input" id="evStatus"><option value="auto">Auto (by date)</option><option value="upcoming">Upcoming</option><option value="pending">Pending</option><option value="ended">Ended</option></select></label>' +
        '<label style="grid-column:1/-1">Description<textarea class="input" id="evDesc" rows="3" maxlength="800" placeholder="Short description"></textarea></label>' +
        '<label style="grid-column:1/-1">Registration &amp; Info link<input class="input" id="evRegLink" type="url" maxlength="400" placeholder="https://… (Google Form / page link)"></label>' +
        '</div>' +
        '<input type="hidden" id="evEditId" value="">' +
        '<div class="admin-actions" style="margin-top:12px">' +
        '<button type="button" class="btn btn-primary btn-sm" data-act="event-save">Save event</button>' +
        '<button type="button" class="btn btn-ghost btn-sm" data-act="event-reset">Cancel</button>' +
        '</div><small>Status Auto: past date → ended, today → pending, future → upcoming. You can still set status manually.</small></div>' +
        '<div class="admin-table-wrap" style="margin-top:18px"><table class="admin-table"><thead><tr><th>Event</th><th>Date / Time</th><th>Status</th><th>Actions</th></tr></thead><tbody>' + rows + '</tbody></table></div></div>';
    }

    function detailPanel(m) {
      if (!m) return '';
      return '<div class="admin-detail" id="adminDetail">' +
        '<div style="display:flex;align-items:center;gap:14px;margin-bottom:12px">' +
        '<img class="avatar" src="' + (m.photo || L.avatar(m.name)) + '" width="56" height="56" alt="">' +
        '<div><h2>' + esc(m.name) + (m.verified ? ' ' + L.verifiedBadge() : '') + '</h2>' +
        '<div class="meta">' + esc(L.profile.memberIdLabel(m)) + ' · ' + esc(m.email || '—') + '</div></div></div>' +
        '<dl>' +
        '<dt>Status</dt><dd>' + statusPill(m) + '</dd>' +
        '<dt>Verified</dt><dd>' + (m.verified ? 'Yes' : 'No') + '</dd>' +
        '<dt>Position / Title</dt><dd>' + esc(m.role || 'Member') + '</dd>' +
        '<dt>Category</dt><dd>' + esc((m.category === 'General Member' || !m.category) ? 'General' : m.category) + '</dd>' +
        '<dt>Batch</dt><dd>' + esc(m.batch || '—') + '</dd>' +
        '<dt>Phone</dt><dd>' + esc(m.phone || '—') + '</dd>' +
        '<dt>Profession</dt><dd>' + esc(m.profession || '—') + '</dd>' +
        '<dt>Designation</dt><dd>' + esc(m.designation || '—') + '</dd>' +
        '<dt>Organization</dt><dd>' + esc(m.org || '—') + '</dd>' +
        '<dt>Gender</dt><dd>' + esc(m.gender || '—') + '</dd>' +
        '<dt>Date of birth</dt><dd>' + esc(m.dob || '—') + '</dd>' +
        '<dt>Location</dt><dd>' + esc(m.location || '—') + '</dd>' +
        '<dt>Address</dt><dd>' + esc(m.address || '—') + '</dd>' +
        '<dt>Bio</dt><dd>' + esc(m.bio || '—') + '</dd>' +
        '<dt>Skills</dt><dd>' + esc(m.skills || '—') + '</dd>' +
        '<dt>Interests</dt><dd>' + esc(m.interests || '—') + '</dd>' +
        '<dt>Facebook</dt><dd>' + (m.facebook ? '<a target="_blank" rel="noopener noreferrer" href="' + esc(m.facebook) + '">View</a>' : '—') + '</dd>' +
        '<dt>LinkedIn</dt><dd>' + (m.linkedin ? '<a target="_blank" rel="noopener noreferrer" href="' + esc(m.linkedin) + '">View</a>' : '—') + '</dd>' +
        '<dt>Website</dt><dd>' + (m.website ? '<a target="_blank" rel="noopener noreferrer" href="' + esc(m.website) + '">View</a>' : '—') + '</dd>' +
        '<dt>SSC institution</dt><dd>' + esc(m.sscInstitution || '—') + '</dd>' +
        '<dt>HSC passing year</dt><dd>' + esc(m.hsc || '—') + '</dd>' +
        '<dt>HSC institution</dt><dd>' + esc(m.hscInstitution || '—') + '</dd>' +
        '<dt>University / college</dt><dd>' + esc(m.university || '—') + '</dd>' +
        '<dt>Subject</dt><dd>' + esc(m.subject || '—') + '</dd>' +
        '<dt>Bachelor’s year</dt><dd>' + esc(m.bachelor || '—') + '</dd>' +
        '<dt>Master’s year</dt><dd>' + esc(m.master || '—') + '</dd>' +
        '<dt>Verify request</dt><dd>' + (m.verifyRequest && m.verifyRequest.status === 'pending' ? 'Pending since ' + esc(m.verifyRequest.at || '') : 'None') + '</dd>' +
        '</dl>' +
        '<div class="admin-role-editor"><h3>Member information</h3><div class="form-grid">' +
        [['adminNameInput','Name',m.name],['adminDesignationInput','Designation',m.designation],['adminProfessionInput','Profession',m.profession],['adminOrgInput','Organization',m.org],['adminPhoneInput','Phone',m.phone],['adminBatchInput','Batch',m.batch]].map(function (f) { return '<label>' + esc(f[1]) + '<input class="input" id="' + f[0] + '" value="' + esc(f[2] || '') + '"></label>'; }).join('') +
        '</div><button type="button" class="btn btn-primary btn-sm" data-act="save-member" data-id="' + esc(m.id) + '">Save member information</button></div>' +
        '<div class="admin-role-editor">' + roleSelectHtml(m.role || 'Member') +
        '<label for="adminCategoryInput">Member category</label><div class="admin-role-row"><select class="input" id="adminCategoryInput">' + optionList(['Executive', 'Alumni', 'General'], (m.category === 'General Member' || !m.category) ? 'General' : m.category) + '</select>' +
        '<button type="button" class="btn btn-primary btn-sm" data-act="save-role" data-id="' + esc(m.id) + '">Save changes</button></div><small>Choose a position from the list, or pick “Other (type below)” to enter a custom title. Set category to Executive for the board.</small></div>' +
        '<div class="admin-actions" style="margin-top:18px">' +
        (!m.verified ? '<button type="button" class="btn btn-accent btn-sm" data-act="verify" data-id="' + esc(m.id) + '">Verify member</button>' :
          '<button type="button" class="btn btn-outline btn-sm" data-act="unverify" data-id="' + esc(m.id) + '">Remove verification</button>') +
        (m.status === 'pending' ? '<button type="button" class="btn btn-primary btn-sm" data-act="approve" data-id="' + esc(m.id) + '">Approve registration</button><button type="button" class="btn btn-outline btn-sm" data-act="reject" data-id="' + esc(m.id) + '">Reject</button>' : '') +
        (m.status === 'active' || !m.status ? '<button type="button" class="btn btn-outline btn-sm" data-act="suspend" data-id="' + esc(m.id) + '">Suspend</button>' : '') +
        (m.status === 'suspended' || m.status === 'rejected' ? '<button type="button" class="btn btn-primary btn-sm" data-act="activate" data-id="' + esc(m.id) + '">Reactivate</button>' : '') +
        '<button type="button" class="btn btn-ghost btn-sm" data-act="close-detail">Close</button>' +
        '</div></div>';
    }

    function render() {
      if (L.auth.isReady && !L.auth.isReady()) { root.innerHTML = '<section class="card admin-gate"><h1>Loading admin panel</h1><p>Checking your secure account session…</p></section>'; return; }
      var u = L.auth.current();
      if (!u || !L.auth.isAdmin(u)) { gate(); return; }
      document.title = 'Admin Panel — LSU';
      var all = L.members.all();
      var st = stats(all);
      var list;
      if (tab === 'requested') list = all.filter(function (m) {
        return m.verified !== true && (
          m.status === 'pending' ||
          (m.verifyRequest && m.verifyRequest.status === 'pending')
        );
      });
      else if (tab === 'notverified') list = all.filter(function (m) {
        var s = String(m.status || '').toLowerCase();
        return m.verified !== true && s !== 'suspended' && s !== 'rejected';
      });
      else if (tab === 'suspended') list = all.filter(function (m) {
        var s = String(m.status || '').toLowerCase();
        return s === 'suspended' || s === 'rejected';
      });
      else if (tab === 'events') list = [];
      else list = all.filter(function (m) { return m.verified === true; });

      list.sort(function (a, b) { var x = parseInt(a.memberId, 10), y = parseInt(b.memberId, 10); x = isNaN(x) ? 999999999 : x; y = isNaN(y) ? 999999999 : y; return x - y || String(a.name || '').localeCompare(String(b.name || '')); });

      var q = ($('#adminSearch') && $('#adminSearch').value || '').trim().toLowerCase();
      if (q) list = list.filter(function (m) {
        return (m.name || '').toLowerCase().indexOf(q) >= 0 ||
          (m.email || '').toLowerCase().indexOf(q) >= 0 ||
          (m.id || '').toLowerCase().indexOf(q) >= 0 ||
          (m.memberId || '').toLowerCase().indexOf(q) >= 0;
      });

      root.innerHTML =
        '<div class="admin-dash">' +
        '<div class="admin-head"><div><span class="eyebrow">Administration</span><h1>Admin Panel</h1>' +
        '<p>Signed in as ' + esc(u.name) + '. Manage registrations, verification and member records.</p></div>' +
        '<div class="admin-head-actions"><a class="btn btn-outline" href="members.html">Members Directory</a></div></div>' +
        (L.members.loadError && L.members.loadError() ? '<div class="alert alert-error show" role="alert">Member data warning: ' + esc(L.members.loadError()) + '</div>' : '') +
        '<div class="admin-stats">' + st.map(function (s) {
          return '<div class="admin-stat"><strong>' + s[0] + '</strong><span>' + s[1] + '</span></div>';
        }).join('') + '</div>' +
        '<div class="admin-tabs" role="tablist">' +
        [['verified', 'Verified members'], ['requested', 'Requested'], ['notverified', 'Not verified'], ['suspended', 'Suspended'], ['events', 'Events']].map(function (t) {
          return '<button type="button" role="tab" class="' + (tab === t[0] ? 'active' : '') + '" data-tab="' + t[0] + '">' + t[1] + '</button>';
        }).join('') + '</div>' +
        (tab === 'events' ? eventsPanel() :
          ('<div class="admin-toolbar"><input class="input" id="adminSearch" type="search" placeholder="Search by name, email or ID" value="' + esc(q) + '"></div>' +
          table(list) +
          (detailId ? detailPanel(L.members.find(detailId)) : ''))) +
        '</div>';

      bind();
    }

    function bind() {
      root.querySelectorAll('[data-tab]').forEach(function (b) {
        b.addEventListener('click', function () { tab = b.getAttribute('data-tab'); detailId = null; render(); });
      });
      var search = $('#adminSearch');
      if (search) {
        var t;
        search.addEventListener('input', function () {
          clearTimeout(t);
          var el = this;
          t = setTimeout(function () {
            var val = el.value;
            var start = el.selectionStart;
            var end = el.selectionEnd;
            render();
            var again = $('#adminSearch');
            if (again) {
              again.focus();
              try { again.setSelectionRange(start, end); } catch (e) {}
            }
          }, 550);
        });
      }
      var roleSelect = $('#adminRoleSelect');
      if (roleSelect) {
        roleSelect.addEventListener('change', function () {
          var isOther = this.value === 'Other (type below)';
          var wrap = $('#adminRoleCustomWrap');
          var label = $('#adminRoleCustomLabel');
          if (wrap) wrap.style.display = isOther ? '' : 'none';
          if (label) label.style.display = isOther ? '' : 'none';
          var cat = $('#adminCategoryInput');
          if (cat) {
            if (isOther) {
              // leave category; user decides
            } else if (this.value.trim() && this.value.trim() !== 'Member') {
              cat.value = 'Executive';
            } else if (this.value.trim() === 'Member') {
              cat.value = 'General';
            }
          }
          if (isOther) {
            var custom = $('#adminRoleCustom');
            if (custom) custom.focus();
          }
        });
      }
      root.querySelectorAll('[data-act]').forEach(function (b) {
        b.addEventListener('click', function () {
          var act = b.getAttribute('data-act');
          var id = b.getAttribute('data-id');
          if (act === 'close-detail') { detailId = null; render(); return; }
          if (act === 'event-reset') {
            ['evTitle','evDate','evTime','evDesc','evRegLink','evEditId'].forEach(function (id) { var el = $('#' + id); if (el) el.value = ''; });
            var st = $('#evStatus'); if (st) st.value = 'auto';
            var wrap = $('#eventFormWrap'); if (wrap) wrap.style.display = 'none';
            return;
          }
          if (act === 'event-edit') {
            var wrap = $('#eventFormWrap');
            if (wrap) wrap.style.display = '';
            var t = $('#eventFormTitle'); if (t) t.textContent = 'Edit Event';
            var ev = (L.events && L.events.find) ? L.events.find(id) : null;
            if (!ev) { L.toast('Event not found.', 'error'); return; }
            var map = { evTitle: ev.title, evDate: ev.date, evTime: ev.time, evDesc: ev.description, evRegLink: ev.registrationLink || ev.regLink || '', evEditId: ev.id };
            Object.keys(map).forEach(function (k) { var el = $('#' + k); if (el) el.value = map[k] || ''; });
            var st = $('#evStatus'); if (st) st.value = ev.status || 'upcoming';
            return;
          }
          if (act === 'event-delete') {
            if (!confirm('Delete this event permanently?')) return;
            b.disabled = true;
            L.events.remove(id).then(function (r) {
              if (r && r.ok) { L.toast('Event deleted.'); render(); }
              else { L.toast((r && r.error) || 'Could not delete event.', 'error'); b.disabled = false; }
            });
            return;
          }
          if (act === 'event-show-form') {
            var wrap = $('#eventFormWrap');
            if (wrap) wrap.style.display = '';
            var t = $('#eventFormTitle'); if (t) t.textContent = 'Add Event';
            ['evTitle','evDate','evTime','evDesc','evRegLink','evEditId'].forEach(function (id) { var el = $('#' + id); if (el) el.value = ''; });
            var st = $('#evStatus'); if (st) st.value = 'auto';
            return;
          }
          if (act === 'event-save') {
            var payload = {
              title: ($('#evTitle') && $('#evTitle').value || '').trim(),
              date: ($('#evDate') && $('#evDate').value || '').trim(),
              time: ($('#evTime') && $('#evTime').value || '').trim(),
              description: ($('#evDesc') && $('#evDesc').value || '').trim(),
              registrationLink: ($('#evRegLink') && $('#evRegLink').value || '').trim(),
              status: ($('#evStatus') && $('#evStatus').value) || 'auto'
            };
            if (payload.status === 'auto') {
              var today = new Date(); today.setHours(0,0,0,0);
              var d = new Date(payload.date + 'T00:00:00');
              if (!isNaN(d.getTime())) {
                d.setHours(0,0,0,0);
                var diff = d.getTime() - today.getTime();
                payload.status = diff < 0 ? 'ended' : (diff === 0 ? 'pending' : 'upcoming');
              } else payload.status = 'upcoming';
            }
            var editId = ($('#evEditId') && $('#evEditId').value) || '';
            if (!payload.title || !payload.date) { L.toast('Title and date are required.', 'error'); return; }
            if (!confirm(editId ? 'Update this event?' : 'Add this event?')) return;
            b.disabled = true; b.textContent = 'Saving…';
            var p = editId ? L.events.update(editId, payload) : L.events.create(payload);
            p.then(function (r) {
              if (r && r.ok) { L.toast(editId ? 'Event updated.' : 'Event added.'); render(); }
              else { L.toast((r && r.error) || 'Could not save event.', 'error'); b.disabled = false; b.textContent = 'Save event'; }
            });
            return;
          }
          if (act === 'sync-public') {
            if (typeof firebase === 'undefined' || !firebase.functions) {
              L.toast('Firebase Functions SDK is missing. Reload the updated admin page.', 'error');
              return;
            }
            b.disabled = true;
            b.textContent = 'Syncing…';
            firebase.app().functions('us-central1')
              .httpsCallable('backfillPublicMembers')({})
              .then(function (result) {
                var data = result && result.data ? result.data : {};
                L.toast('Public directory synced: ' + (data.verifiedActive || 0) + ' verified active members.');
                if (L.members.refreshPublic) return L.members.refreshPublic();
              })
              .then(function () { render(); })
              .catch(function (err) {
                console.error('[LSU Admin] Public directory sync failed:', err);
                L.toast((err && err.message) || 'Could not sync public directory. Check Functions deployment and permissions.', 'error');
              })
              .finally(function () {
                var current = root.querySelector('[data-act="sync-public"]');
                if (current) { current.disabled = false; current.textContent = 'Sync Public Directory'; }
              });
            return;
          }
          if (act === 'save-member') {
            var patch = { name: $('#adminNameInput').value.trim(), designation: $('#adminDesignationInput').value.trim(), profession: $('#adminProfessionInput').value.trim(), org: $('#adminOrgInput').value.trim(), phone: $('#adminPhoneInput').value.trim(), batch: $('#adminBatchInput').value.trim() };
            b.disabled = true; b.textContent = 'Saving…';
            L.admin.updateMember(id, patch).then(function (r) { if (r && r.ok) { L.toast('Member information updated.'); render(); } else { L.toast((r && r.error) || 'Could not update member.', 'error'); b.disabled = false; b.textContent = 'Save member information'; } });
            return;
          }
          if (act === 'save-role') {
            var roleSelectEl = $('#adminRoleSelect');
            var customEl = $('#adminRoleCustom');
            var newRole = '';
            if (roleSelectEl && roleSelectEl.value === 'Other (type below)') {
              newRole = customEl ? customEl.value.trim() : '';
            } else {
              newRole = roleSelectEl ? roleSelectEl.value.trim() : '';
            }
            if (!newRole) {
              L.toast('Please select or type a role/position.', 'error');
              return;
            }
            if (!confirm('Save role and category for this member?')) return;
            var categoryInput = $('#adminCategoryInput');
            var newCategory = categoryInput ? categoryInput.value : 'General';
            b.disabled = true; b.textContent = 'Saving…';
            L.admin.setRole(id, newRole, newCategory).then(function (r) {
              if (r && r.ok) { L.toast('Position updated successfully.'); render(); }
              else { L.toast((r && r.error) || 'Could not update position.', 'error'); b.disabled = false; b.textContent = 'Save position'; }
            });
            return;
          }
          if (act === 'detail') { detailId = id; render(); return; }
          var res;
          var actionPromise = null;
          if (act === 'approve') {
            if (!confirm('Approve this registration?')) return;
            actionPromise = L.admin.approve(id);
          }
          else if (act === 'reject') {
            if (!confirm('Reject this registration?')) return;
            actionPromise = L.admin.reject(id);
          }
          else if (act === 'verify') {
            if (!confirm('Verify this member?')) return;
            var selectedRole = $('#adminRoleSelect'), selectedCategory = $('#adminCategoryInput'), customRole = $('#adminRoleCustom');
            if (selectedRole && selectedCategory) {
              var roleVal = selectedRole.value === 'Other (type below)'
                ? (customRole ? customRole.value.trim() : '')
                : selectedRole.value.trim();
              actionPromise = (roleVal
                ? L.admin.setRole(id, roleVal, selectedCategory.value)
                : Promise.resolve({ ok: true })
              ).then(function (saved) {
                return saved && saved.ok ? L.admin.setVerified(id, true) : saved;
              });
            } else actionPromise = L.admin.setVerified(id, true);
          }
          else if (act === 'unverify') {
            if (!confirm('Remove verification from this member?')) return;
            actionPromise = L.admin.setVerified(id, false);
          }
          else if (act === 'suspend') {
            if (!confirm('Suspend this member?')) return;
            actionPromise = L.admin.setStatus(id, 'suspended');
          }
          else if (act === 'activate') {
            if (!confirm('Reactivate this member?')) return;
            actionPromise = L.admin.setStatus(id, 'active');
          }
          else if (act === 'delete-member') {
            if (!confirm('Permanently delete this member record from Firestore? This cannot be undone.')) return;
            actionPromise = L.admin.removeMember(id);
          }
          if (!actionPromise) return;
          b.disabled = true;
          Promise.resolve(actionPromise).then(function (res) {
            if (res && res.ok) {
              L.toast(act.charAt(0).toUpperCase() + act.slice(1) + ' successful.');
              render();
            } else {
              L.toast((res && res.error) || 'Action failed.', 'error');
              b.disabled = false;
            }
          }).catch(function (err) {
            console.error('[LSU Admin] Action failed:', err);
            L.toast((err && err.message) || 'Action failed. Check Firebase permissions/quota.', 'error');
            b.disabled = false;
          });
        });
      });
    }

    document.addEventListener('lsu:authchange', render);
    document.addEventListener('lsu:eventschange', render);
    render();
  }
  if (window.LSU && window.LSU.isReady) start();
  else document.addEventListener('lsu:ready', start, { once: true });
})();
