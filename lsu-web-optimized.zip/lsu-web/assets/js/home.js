/* Home page behaviour. Public page: never redirects, never requires sign-in. */
(function () {
  'use strict';
  function start() {
    var L = window.LSU, el = L.$;

    function arrow() { return L.icon('arrow'); }

    function renderHero() {
      var u = L.auth.current();
      el('#heroCta').innerHTML = u
        ? '<a class="btn btn-accent" href="members.html">Open Members Directory ' + arrow() + '</a>' +
          '<a class="btn btn-line-light" href="profile.html">My Profile</a>' +
          '<a class="btn btn-line-light" href="committee.html">Executive Board</a>'
        : '<a class="btn btn-accent" href="register.html">Become a Member ' + arrow() + '</a>' +
          '<a class="btn btn-line-light" href="login.html">Sign In</a>' +
          '<a class="btn btn-line-light" href="committee.html">Executive Board</a>';
    }

    function publicDirectory() {
      return (L.members.publicAll ? L.members.publicAll() : []).filter(function (m) {
        return m && m.verified === true && String(m.status || '').toLowerCase() === 'active';
      });
    }

    function renderStats() {
      var publicError = L.members.publicLoadError && L.members.publicLoadError();
      var allPublic = publicDirectory();
      var verified = publicError ? '—' : allPublic.length;
      var executives = publicError ? '—' : allPublic.filter(function (m) {
        return String(m.category || '').trim().toLowerCase() === 'executive';
      }).length;
      var events = (L.events && L.events.all) ? L.events.all() : (L.data.EVENTS || []);
      var upcoming = events.filter(function (e) {
        var st = String(e.status || '').toLowerCase();
        if (st === 'ended') return false;
        if (st === 'upcoming' || st === 'pending') return true;
        return e.date && !L.isPast(e.date);
      }).length;

      var items = [
        ['calendar', L.config.est || '2007', 'Established'],
        ['shield', verified, 'Verified members'],
        ['board', executives, 'Executive members'],
        ['calendar', upcoming, 'Upcoming events']
      ];
      el('#stats').innerHTML = items.map(function (s) {
        return '<div class="stat"><span class="stat-icon">' + L.icon(s[0]) + '</span><div><strong>' + L.esc(s[1]) + '</strong><span>' + s[2] + '</span></div></div>';
      }).join('');
    }

    function renderBoard() {
      var publicMembers = L.members.publicAll ? L.members.publicAll() : [];
      if (L.members.publicLoadError && L.members.publicLoadError()) {
        el('#boardGrid').innerHTML = '<article class="card leader leader-president leader-centered"><span class="leader-eyebrow">PRESIDENT</span><h3>President information unavailable</h3><p class="empty-note">' + L.esc(L.members.publicLoadError()) + '</p></article>';
        return;
      }
      var record = publicMembers.find(function (m) {
        if (!m) return false;
        var status = String(m.status || '').toLowerCase();
        var verified = m.verified === true || m.verified === 'true' || m.verified === 1;
        if (!verified || status !== 'active') return false;
        var role = String(m.role || m.position || '').trim().toLowerCase();
        var des = String(m.designation || '').trim().toLowerCase();
        return role === 'president' || des === 'president';
      });
      if (!record) {
        el('#boardGrid').innerHTML =
          '<article class="card leader leader-president leader-centered">' +
            '<span class="leader-eyebrow">PRESIDENT</span>' +
            '<h3>President</h3>' +
            '<p class="empty-note">No verified Executive President is currently listed.</p>' +
          '</article>';
        return;
      }
      var displayName = String(record.name || 'President');
      var initials = displayName.split(/\s+/).slice(0, 2).map(function (p) { return p.charAt(0); }).join('').toUpperCase();
      var avatar = record.photo
        ? '<img class="leader-avatar leader-avatar-border" src="' + L.esc(record.photo) + '" alt="' + L.esc(displayName) + '">'
        : '<div class="leader-avatar leader-avatar-border" aria-hidden="true">' + L.esc(initials) + '</div>';
      el('#boardGrid').innerHTML =
        '<article class="card leader leader-president leader-centered">' +
          avatar +
          '<span class="leader-eyebrow">PRESIDENT</span>' +
          '<h3>' + L.esc(displayName) + '</h3>' +
          '<span class="tag tag-gold">President, LSU</span>' +
          '<a class="link-arrow" href="profile.html?id=' + encodeURIComponent(record.uid || record.id) + '">View profile ' + arrow() + '</a>' +
        '</article>';
    }

    function renderEvents() {
      var events = (L.events && L.events.all) ? L.events.all() : (L.data.EVENTS || []);
      var up = events.filter(function (e) {
        var st = String(e.status || '').toLowerCase();
        if (st === 'ended') return false;
        if (st === 'upcoming' || st === 'pending') return true;
        return e.date && !L.isPast(e.date);
      }).sort(function (a, b) {
        return String(a.date || '').localeCompare(String(b.date || ''));
      }).slice(0, 3);
      el('#eventList').innerHTML = up.length ? up.map(function (e) {
        var d = e.date ? new Date(e.date + 'T00:00:00') : null;
        var dateLabel = d && !isNaN(d) ? (String(d.getDate()).padStart(2, '0') + ' ' + d.toLocaleString('en', { month: 'short' })) : '—';
        var link = String(e.registrationLink || e.regLink || '').trim();
        var btn = link
          ? '<a class="btn btn-primary btn-sm event-reg-btn" href="' + L.esc(link) + '" target="_blank" rel="noopener noreferrer">Registration &amp; Info</a>'
          : '';
        return '<article class="event"><div class="event-date" aria-hidden="true"><b>' + (d && !isNaN(d) ? String(d.getDate()).padStart(2, '0') : '—') + '</b><small>' +
          (d && !isNaN(d) ? d.toLocaleString('en', { month: 'short' }) : '') + '</small></div><div><h3 class="event-title">' + L.esc(e.title || 'Event') + '</h3>' +
          '<p class="meta event-time">' + L.esc(e.status || 'upcoming') + (e.time ? ' · ' + L.esc(e.time) : '') + '</p>' +
          '<p class="event-desc">' + L.esc((e.description || '').slice(0, 140)) + '</p>' +
          (btn ? '<div class="event-actions" style="margin-top:8px">' + btn + '</div>' : '') +
          '</div></article>';
      }).join('') : '<p class="empty-note">No upcoming events right now. Please check back soon.</p>';
    }

    function renderCta() {
      var u = L.auth.current();
      el('#ctaBand').innerHTML = u
        ? '<div><h2>Welcome back, ' + L.esc(String(u.name).split(' ')[0]) + '</h2><p>' + (u.verified ? 'Your membership is verified by LSU.' : 'Your account is awaiting verification by an LSU administrator.') + '</p></div>' +
          '<div class="cta-actions"><a class="btn btn-light" href="members.html">Members Directory</a><a class="btn btn-line-light" href="profile.html">My Profile</a></div>'
        : '<div><h2>Join the LSU community</h2><p>Anyone can register. New accounts start as Unverified — an LSU administrator reviews and verifies members.</p></div>' +
          '<div class="cta-actions"><a class="btn btn-light" href="register.html">Register</a><a class="btn btn-line-light" href="login.html">Sign In</a></div>';
    }

    function renderAll() {
      renderHero();
      renderStats();
      renderBoard();
      renderEvents();
      renderCta();
    }

    document.addEventListener('lsu:authchange', renderAll);
    document.addEventListener('lsu:publicmemberschange', renderAll);
    document.addEventListener('lsu:eventschange', renderAll);

    L.ready(function () {
      renderAll();
      if (L.members.refreshPublic) {
        L.members.refreshPublic().then(renderAll).catch(function () { renderAll(); });
      }
      // Only administrators need the private full-member cache for the
      // Registered Members statistic. Public pages already use the public
      // verified-member listener; fetching it again wastes reads.
      var signedIn = L.auth.current();
      if (signedIn && signedIn.admin === true && L.members.refresh) {
        L.members.refresh().then(renderAll).catch(function () {});
      }
    });
  }

  if (window.LSU) window.LSU.ready(start);
  else window.addEventListener('load', function () { if (window.LSU) window.LSU.ready(start); });
})();
