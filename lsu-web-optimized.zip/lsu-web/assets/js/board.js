/* Dynamic public Executive Board. Firebase public directory is a sanitized
   projection of the existing members collection; no static roster is used. */
(function () {
  'use strict';
  // Priority order. "Joint Secretary" is treated as Joint General Secretary.
  var POSITION_ORDER = [
    'President',
    'Senior Vice President',
    'Vice President',
    'General Secretary',
    'Joint Secretary',
    'Treasurer',
    'Administrative Secretary',
    'Planning & Strategy Secretary',
    'Organizing Secretary',
    'Office Secretary',
    'Member Development Secretary',
    'Cultural Secretary',
    'Assistant Cultural Secretary',
    'Event Coordinator',
    'Assistant Event Coordinator',
    'Public Relations Head',
    'Assistant Public Relations Head',
    'Academic Coordinator',
    'Assistant Academic Coordinator',
    'Publication Head',
    'Assistant Publication Head',
    'IT Coordinator',
    'Assistant IT Coordinator',
    'Sports Secretary',
    'Assistant Sports Secretary',
    'Research & Analysis Coordinator',
    'Asst. Research & Analysis Coordinator',
    'Legal Affairs & Policy Coordinator',
    'Asst. Legal Affairs & Policy Coordinator',
    'Alumni Coordinator',
    'Assistant Alumni Coordinator',
    'Women Affairs Secretary',
    'Assistant Women Affairs Secretary',
    'Career Development Secretary',
    'Asst. Career Development Secretary',
    'Partnership & Outreach Secretary',
    'Asst. Partnership & Outreach Secretary',
    'Volunteer Coordinator',
    'Assistant Volunteer Coordinator',
    'Blood Donation Coordinator',
    'Asst. Blood Donation Coordinator',
    'Local Development Coordinator',
    'Asst. Local Development Coordinator'
  ];
  var ROLE_ALIASES = {
    'joint secretary': 'Joint General Secretary',
    'joint gen. secretary': 'Joint General Secretary',
    'joint gen secretary': 'Joint General Secretary',
    'jt. general secretary': 'Joint General Secretary',
    'jt general secretary': 'Joint General Secretary'
  };

  function start() {
    var L = window.LSU, root = L.$('#boardFull');
    if (!root) return;
    var panel = window.LSU_EXECUTIVE_PANEL || { tagline: '' };

    function initials(name) {
      return String(name || '').trim().split(/\s+/).slice(0, 2)
        .map(function (part) { return part.charAt(0); }).join('').toUpperCase() || 'LSU';
    }

    function roleOf(member) {
      var raw = String(member.role || member.position || '').trim().replace(/\s+/g, ' ');
      if (!raw) return '';
      var key = raw.toLowerCase();
      if (ROLE_ALIASES[key]) return ROLE_ALIASES[key];
      return raw;
    }

    function rank(role) {
      var normalized = role;
      var key = role.toLowerCase();
      if (ROLE_ALIASES[key]) normalized = ROLE_ALIASES[key];
      var index = POSITION_ORDER.findIndex(function (name) {
        return name.toLowerCase() === normalized.toLowerCase();
      });
      return index < 0 ? POSITION_ORDER.length : index;
    }

    function displayRole(role) {
      // Prefer the original database value for display when it is a common short form.
      return role || 'Other Executive Position';
    }

    function render() {
      var executives = (L.members.publicAll ? L.members.publicAll() : []).filter(function (m) {
        if (!m) return false;
        var category = String(m.category || '').trim().toLowerCase();
        var status = String(m.status || '').toLowerCase();
        var verified = m.verified === true || m.verified === 'true' || m.verified === 1;
        return verified && status === 'active' && category === 'executive';
      });
      // De-duplicate by Firebase document identity, never by name.
      var seen = Object.create(null);
      executives = executives.filter(function (m) {
        var id = String(m.uid || m.id || '');
        if (!id || seen[id]) return false;
        seen[id] = true;
        return true;
      }).sort(function (a, b) {
        var ar = roleOf(a), br = roleOf(b);
        var diff = rank(ar) - rank(br);
        if (diff) return diff;
        if (rank(ar) === POSITION_ORDER.length) {
          var roleDiff = ar.localeCompare(br, undefined, { sensitivity: 'base' });
          if (roleDiff) return roleDiff;
        }
        return String(a.name || '').localeCompare(String(b.name || ''), undefined, { sensitivity: 'base' });
      });

      var groups = [];
      executives.forEach(function (member) {
        // Use original role string for grouping/display so "Joint Secretary" stays as entered.
        var originalRole = String(member.role || member.position || '').trim().replace(/\s+/g, ' ') || 'Other Executive Position';
        var group = groups.find(function (item) { return item.designation === originalRole; });
        if (!group) {
          group = { designation: originalRole, sortKey: roleOf(member), members: [] };
          groups.push(group);
        }
        group.members.push(member);
      });

      // Re-sort groups by the normalized rank so aliases land in the correct priority slot.
      groups.sort(function (a, b) {
        var ra = rank(a.sortKey || a.designation), rb = rank(b.sortKey || b.designation);
        if (ra !== rb) return ra - rb;
        return String(a.designation).localeCompare(String(b.designation), undefined, { sensitivity: 'base' });
      });

      var total = executives.length;
      root.innerHTML =
        '<div class="board-intro">' +
          '<span class="board-kicker">LALMOHAN STUDENTS’ UNION</span>' +
          '<h2>Executive Board</h2>' +
          '<p class="board-tagline">' + L.esc(panel.tagline || '') + '</p>' +
          '<div class="board-summary">' +
            '<span><strong>' + total + '</strong> Verified Executive Members</span>' +
            '<span><strong>' + groups.length + '</strong> Active Positions</span>' +
          '</div>' +
        '</div>' +
        (groups.length ? groups.map(function (group, index) {
          return (
            '<section class="board-section" aria-labelledby="board-group-' + index + '">' +
              '<div class="board-section-head">' +
                '<span class="board-index">' + String(index + 1).padStart(2, '0') + '</span>' +
                '<h3 id="board-group-' + index + '">' + L.esc(group.designation) + '</h3>' +
                '<span class="board-count">' + group.members.length +
                  (group.members.length === 1 ? ' member' : ' members') + '</span>' +
              '</div>' +
              '<div class="board-member-grid">' +
                group.members.map(function (m) {
                  var id = String(m.uid || m.id);
                  var name = String(m.name || 'Member');
                  var avatar = m.photo
                    ? '<img class="board-avatar" src="' + L.esc(m.photo) + '" alt="' + L.esc(name) + '" loading="lazy">'
                    : '<div class="board-avatar" aria-hidden="true">' + L.esc(initials(name)) + '</div>';
                  var metaParts = [];
                  if (m.memberId) metaParts.push(L.esc(String(m.memberId)));
                  if (m.batch) metaParts.push('Batch ' + L.esc(String(m.batch)));
                  var meta = metaParts.join(' · ');
                  var profession = m.profession ? '<p class="board-profession">' + L.esc(String(m.profession)) + '</p>' : '';
                  var badge = (m.verified === true) ? (L.verifiedBadge ? L.verifiedBadge() : '') : '';
                  return (
                    '<article class="card board-card">' +
                      '<a class="board-profile-link" href="profile.html?id=' + encodeURIComponent(id) + '" aria-label="View ' + L.esc(name) + ' profile">' +
                        avatar +
                        '<h4>' + L.esc(name) + badge + '</h4>' +
                      '</a>' +
                      '<span class="board-role">' + L.esc(group.designation) + '</span>' +
                      (meta ? '<p class="board-member-meta">' + meta + '</p>' : '') +
                      profession +
                      '<a class="link-arrow" href="profile.html?id=' + encodeURIComponent(id) + '">View profile ' + L.icon('arrow') + '</a>' +
                    '</article>'
                  );
                }).join('') +
              '</div>' +
            '</section>'
          );
        }).join('') : '<div class="card admin-empty">No verified, active Executive members are currently listed.</div>');
    }

    document.addEventListener('lsu:authchange', render);
    document.addEventListener('lsu:publicmemberschange', render);
    L.ready(function () {
      render();
      if (L.members.refreshPublic) L.members.refreshPublic().then(render).catch(render);
    });
  }

  if (window.LSU) window.LSU.ready(start);
  else window.addEventListener('load', function () { if (window.LSU) window.LSU.ready(start); });
})();
