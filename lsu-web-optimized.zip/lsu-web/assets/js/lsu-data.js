/* LSU seed data — events and offline fallback.
   Live members come from Firebase Firestore when configured. */
(function () {
  'use strict';
  if (window.LSU_DATA) return;

  var MEMBERS = [];

  var EVENTS = [];

  window.LSU_DATA = { MEMBERS: MEMBERS, EVENTS: EVENTS };
})();
