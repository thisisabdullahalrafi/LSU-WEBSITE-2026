/* Events page — upcoming/pending on top, ended at bottom. */
(function () {
  'use strict';
  function start() {
    var L = window.LSU, $ = L.$, esc = L.esc;

    function isEnded(e) {
      var st = String(e.status || '').toLowerCase();
      if (st === 'ended') return true;
      if (st === 'upcoming' || st === 'pending') return false;
      return e.date ? L.isPast(e.date) : false;
    }

    function card(e) {
      var st = String(e.status || (isEnded(e) ? 'ended' : 'upcoming')).toLowerCase();
      var link = String(e.registrationLink || e.regLink || '').trim();
      var btn = link
        ? '<a class="btn btn-primary btn-sm event-reg-btn" href="' + esc(link) + '" target="_blank" rel="noopener noreferrer">Registration &amp; Info</a>'
        : '';
      return '<article class="card list-card event-card">' +
        '<span class="tag">' + esc(st) + '</span>' +
        '<h3 class="event-title">' + esc(e.title || 'Event') + '</h3>' +
        '<div class="meta event-time">' + esc(e.date ? L.fmtDate(e.date) : '—') + (e.time ? ' · ' + esc(e.time) : '') + '</div>' +
        '<p class="event-desc">' + esc(e.description || e.summary || '') + '</p>' +
        (btn ? '<div class="event-actions">' + btn + '</div>' : '') +
        '</article>';
    }

    function render() {
      var events = (L.events && L.events.all) ? L.events.all() : (L.data.EVENTS || []);
      var upcoming = [], past = [];
      events.forEach(function (e) {
        (isEnded(e) ? past : upcoming).push(e);
      });
      upcoming.sort(function (a, b) {
        return String(a.date || '').localeCompare(String(b.date || ''));
      });
      past.sort(function (a, b) {
        return String(b.date || '').localeCompare(String(a.date || ''));
      });
      var upEl = $('#upcomingList');
      var pastEl = $('#pastList');
      if (upEl) upEl.innerHTML = upcoming.length ? upcoming.map(card).join('') : '<p style="color:var(--muted)">No upcoming events listed.</p>';
      if (pastEl) pastEl.innerHTML = past.length ? past.map(card).join('') : '<p style="color:var(--muted)">No past events listed.</p>';
    }

    document.addEventListener('lsu:eventschange', render);
    if (L.events && L.events.refresh) {
      L.events.refresh().then(render).catch(render);
    } else {
      render();
    }
  }
  if (window.LSU && window.LSU.isReady) start();
  else document.addEventListener('lsu:ready', start, { once: true });
})();
