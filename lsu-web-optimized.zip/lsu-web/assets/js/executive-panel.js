/* Executive Board presentation metadata only. Member names and positions are
   always read from the Firebase-backed public member directory. */
(function () {
  'use strict';
  window.LSU_EXECUTIVE_PANEL = {
    organization: "Lalmohan Students’ Union",
    title: 'Executive Board',
    tagline: 'একা নয় যৌথ প্রয়াসে এগিয়ে যাব, বন্ধুর হলেও সে পথেই পা বাড়াবো।'
  };
})();
