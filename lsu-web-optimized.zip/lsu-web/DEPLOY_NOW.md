# আর Sync লাগবে না

## নতুন নিয়ম
Executive Board ও Home count সরাসরি Firestore `members` কালেকশন থেকে পড়ে।

- যার `verified == true` এবং `status == active` এবং `category === "Executive"`
- তারাই Board-এ দেখাবে
- আলাদা `publicMembers` sync দরকার নেই

## আপনার করণীয়

### ১) Rules আবার Publish (জরুরি)
Firebase Console → Firestore → Rules → নিচের পুরো কোড পেস্ট → Publish

(ZIP-এর `firestore.rules` ফাইলও একই)

### ২) এই ZIP Netlify-তে আপলোড
পুরনো ফাইল রিপ্লেস করুন।

### ৩) কিছুই Sync করতে হবে না
Admin Panel থেকে শুধু নিশ্চিত করুন মেম্বারের:
- Category = `Executive` (ঠিক এই বানান)
- Verified = yes
- Status = active

তাহলেই Board-এ চলে আসবে।
