# Lalmohan Students’ Union (LSU) — Production Website

Firebase Auth + Firestore powered professional website for Lalmohan Students’ Union (est. 2007).

## Executive Board (Dynamic)

The Executive Board (`committee.html`) is fully dynamic:

- Source of truth: existing Firestore `members` collection only.
- Public read model: sanitized `publicMembers` projection maintained by Cloud Function `syncPublicMember`.
- Filter (exact, case-sensitive): `category === "Executive"` **and** `verified === true` **and** `status === "active"`.
- No hardcoded roster, no duplicate member database.
- Position priority order:
  1. President
  2. Senior Vice President
  3. Vice President
  4. General Secretary
  5. Joint General Secretary (also accepts “Joint Secretary”)
  6. Organizing Secretary
  7. Finance Secretary
  8. Office Secretary
  9. All other Executive positions (alphabetical), then name within position.
- Cards show real profile photo, full name + verified badge, position, Member ID · Batch, profession (when present), and a link to the real `profile.html?id=<uid>`.
- Live updates via Firestore `onSnapshot` on `publicMembers`. Admin category/position/photo changes appear automatically.
- Homepage President card is also driven by the same live data (no hardcoded name/photo).

## Deploy (Ready to use)

1. Upload this folder to Netlify (publish directory = root containing `index.html`).
2. Firebase project is already configured in `assets/js/firebase-config.js` (project `lsu-test` or your current project — do not invent new keys).
3. Firebase Console → Authentication → Sign-in method → **Email/Password** → Enable.
4. Publish rules:
   ```bash
   firebase deploy --only firestore:rules,storage
   ```
5. Deploy Cloud Functions (required for publicMembers sync):
   ```bash
   cd functions
   npm install
   cd ..
   firebase deploy --only functions
   ```
6. Add your Netlify domain under Firebase Authentication → Settings → Authorized domains.
7. Sign in once with the bootstrap admin email (`support.eyms@gmail.com` or whatever is configured) so the account receives `admin: true`.
8. The public directory reads a sanitized `publicMembers` projection. Cloud Functions keep it synchronized with the source-of-truth `members` collection. After the first deployment, sign in as Admin and use **Sync Public Directory** once to backfill existing accounts.

After deploy, changing a member’s Category to `Executive` (and verifying + activating them) makes them appear on the board; changing Category away from Executive or suspending them removes them. Position changes re-sort the board live.

## Admin capabilities
- Approve / reject registrations
- Verify / Unverify (Member ID auto-assigned 1001+)
- Suspend / Reactivate
- Assign or change Executive Board role + Category

## Security model (preserved)
- `members` is the only source of truth. Private fields (email, phone, etc.) never leave the members document for public reads.
- `publicMembers` is a read-only sanitized projection written only by Cloud Functions (Admin SDK). Client writes are denied by rules.
- Ordinary members cannot change their own `role`, `category`, `verified`, `status`, or `admin` flags.
- Only accounts with `admin: true` can modify those fields.

## Pages
Home · About · Executive Board · Members · Profile · Events · Contact · Technology · Login · Register · Forgot Password · Admin

## Official links
- Facebook: https://www.facebook.com/lalmohanstudentsunion/
- LinkedIn: https://www.linkedin.com/company/lalmohan-students-union

See also: `FIREBASE_SETUP.md`, `EXECUTIVE_PANEL_IMPLEMENTATION_REPORT.md`, `TESTING_REPORT.md`
