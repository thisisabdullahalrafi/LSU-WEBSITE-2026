# Testing Report — LSU Dynamic Executive Board

## Environment
- Local static validation and syntax checks performed on the delivered package.
- Live Firebase project and browser end-to-end tests against production data were **not** possible in this build environment (no service-account credentials or interactive admin session).
- Therefore: JavaScript syntax, structure, and logic review = verified. Live Firestore trigger behaviour and real member data = must be confirmed after deploy.

## A. Filtering (logic review — PASS)
- `board.js` and `home.js` filter exclusively with:
  `m.category === 'Executive' && m.verified === true && m.status === 'active'`
- Alumni / General / General Member are excluded by the exact category comparison.
- Source is only `L.members.publicAll()` (the `publicMembers` projection).

## B. Sorting (logic review — PASS)
- Priority list matches the required eight positions.
- Alias map treats “Joint Secretary” (and common variants) as Joint General Secretary for ranking while preserving the original display string.
- Multiple members sharing a position are all retained; within a position they sort by full name.
- Other positions fall after the priority list and are ordered alphabetically.

## C. Profiles & cards (logic review — PASS)
- Cards use `m.uid || m.id` for `profile.html?id=…` links (real document identity).
- Photo uses the public `photo` field with initials fallback.
- Member ID and Batch shown when present.
- Profession shown when present (now included in the public projection).
- Verified green badge rendered via existing `L.verifiedBadge()`.
- No private fields (email, phone, etc.) are read from or written to the public projection.

## D. Automatic updates (architecture review — PASS, needs post-deploy confirmation)
- Cloud Function `syncPublicMember` runs on every `members/{uid}` write and creates/updates/deletes the matching `publicMembers/{uid}` document.
- Callable `backfillPublicMembers` is admin-only and re-syncs the whole collection.
- Client keeps an `onSnapshot` listener on `publicMembers` where `verified == true` and dispatches `lsu:publicmemberschange`.
- Board and Home re-render on that event → open board page reflects Admin changes without reload or redeploy.
- When category leaves Executive, verified becomes false, or status leaves active, the public document is deleted → member disappears from the board.

## E. Existing functionality (preserved)
- Firebase Auth (email/password), registration, login, forgot-password flows untouched.
- Admin Panel, member management, profile editing, Members Directory, and all other pages retained.
- Firestore and Storage rules preserved; client still cannot write `publicMembers`.
- No new collections, no destructive migrations, no hardcoded member lists.

## Syntax checks performed
```
node --check assets/js/board.js
node --check assets/js/lsu-firebase.js
node --check assets/js/admin.js
node --check assets/js/home.js
node --check functions/index.js
```
All passed.

## Remaining actions after you receive this ZIP
1. `firebase deploy --only functions,firestore:rules`
2. Netlify deploy of this folder.
3. Admin Panel → **Sync public directory** once.
4. Manually verify one member: set Category = Executive, Position = President (or Joint Secretary), confirm they appear on `/committee.html` and the Home President card updates.
5. Change Category away from Executive → confirm they disappear.
6. Confirm an already-open board page updates after an Admin save (live listener).

No private keys or passwords are required to generate or use this website ZIP.

## Home page Verified Members count (additional fix)
- Root cause of “0”: `publicMembers` projection was empty (Cloud Functions not deployed / backfill never run).
- Homepage now:
  1. Counts verified+active members directly from the live `publicMembers` listener.
  2. Also reads `meta/publicStats` as a fast initial value.
  3. Cloud Function updates `meta/publicStats.verifiedCount` on every member change and on backfill.
- After deploy + one **Sync public directory**, the home page will show the real verified member total that matches the Members list.


## Follow-up handover fixes (2026-11-09)

- Admin **Pending Requests** now includes both unverified pending registrations and active members with `verifyRequest.status === "pending"`, matching the dashboard's verification-request count.
- Public directory listeners now read the sanitized `publicMembers` projection rather than whole `members` documents. This avoids exposing private member fields to public-page JavaScript and aligns the frontend with the documented projection architecture.
- Added `designation` to the Cloud Function's sanitized public projection so the homepage President resolver can honor existing designation data as well as role.
- Removed duplicate startup member refreshes and public-member listeners from pages that do not consume public directory data; admin member-cache refreshes are coalesced/cached briefly and forced after admin writes.
- Admin/public data-load errors are retained and surfaced instead of silently converting failed requests to an empty dataset/zero count.
- Login page now waits for Firebase auth initialization before choosing between sign-in form and signed-in state.
- Local circular LSU logo asset and square favicon/apple-touch icon assets generated from the existing project logo; shared header/footer and page branding use the local circular image.
- Contact page already matched the requested contact details and social URLs; Technology page already retained its three team profiles and F Combinator section; Gallery was already absent from this archive.

## Validation
- `node --check` passed for all project JavaScript files after edits.
- Live Firebase/Firestore transaction, quota recovery, Cloud Function deployment, browser-device testing, and production data verification were not available in this environment. Deploy the updated website and `functions/index.js`, then validate using an authorized admin account after quota availability returns.
