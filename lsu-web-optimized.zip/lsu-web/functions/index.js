const { onDocumentWritten } = require('firebase-functions/v2/firestore');
const { onCall, HttpsError } = require('firebase-functions/v2/https');
const { initializeApp } = require('firebase-admin/app');
const { getFirestore, FieldValue } = require('firebase-admin/firestore');

initializeApp();
const db = getFirestore();
const REGION = 'us-central1';

function isVerifiedActive(data) {
  if (!data) return false;
  const verified = data.verified === true || data.verified === 'true' || data.verified === 1;
  const status = String(data.status || '').toLowerCase();
  return verified && status === 'active';
}

function publicProjection(uid, data) {
  let category = String(data.category || 'General Member').trim();
  if (category === 'General') category = 'General Member';
  return {
    uid,
    id: uid,
    name: String(data.name || ''),
    photo: String(data.photo || ''),
    role: String(data.role || data.position || 'Member'),
    designation: String(data.designation || ''),
    category,
    memberId: String(data.memberId || ''),
    batch: String(data.batch || ''),
    profession: String(data.profession || ''),
    org: String(data.org || ''),
    verified: true,
    status: 'active',
    updatedAt: FieldValue.serverTimestamp()
  };
}

async function recomputePublicStats() {
  const snap = await db.collection('members').get();
  let registered = 0;
  let verified = 0;
  let executives = 0;
  snap.forEach((doc) => {
    const data = doc.data() || {};
    registered += 1;
    if (isVerifiedActive(data)) {
      verified += 1;
      const cat = String(data.category || '').trim().toLowerCase();
      if (cat === 'executive') executives += 1;
    }
  });
  await db.collection('meta').doc('publicStats').set({
    registered,
    verified,
    executives,
    updatedAt: FieldValue.serverTimestamp()
  }, { merge: true });
  return { registered, verified, executives };
}

async function syncOne(uid, data) {
  const ref = db.collection('publicMembers').doc(uid);
  if (isVerifiedActive(data)) {
    await ref.set(publicProjection(uid, data), { merge: true });
  } else {
    await ref.delete();
  }
}

exports.syncPublicMember = onDocumentWritten({ document: 'members/{uid}', region: REGION }, async (event) => {
  const after = event.data && event.data.after;
  await syncOne(event.params.uid, after && after.exists ? after.data() : null);
  // Keep public stats in sync after every member write.
  try {
    await recomputePublicStats();
  } catch (err) {
    console.error('publicStats recompute failed', err);
  }
});

exports.backfillPublicMembers = onCall({ region: REGION }, async (request) => {
  if (!request.auth) throw new HttpsError('unauthenticated', 'Sign in required.');
  const actor = await db.collection('members').doc(request.auth.uid).get();
  if (!actor.exists || actor.data().admin !== true) {
    throw new HttpsError('permission-denied', 'Main Admin access required.');
  }

  const snap = await db.collection('members').get();
  let batch = db.batch();
  let writesInBatch = 0;
  let count = 0;
  let batchesCommitted = 0;

  for (const doc of snap.docs) {
    const data = doc.data() || {};
    const ref = db.collection('publicMembers').doc(doc.id);
    if (isVerifiedActive(data)) {
      batch.set(ref, publicProjection(doc.id, data), { merge: true });
      count += 1;
    } else {
      batch.delete(ref);
    }
    writesInBatch += 1;

    // Firestore allows at most 500 writes per batch. Keep a safety margin.
    if (writesInBatch >= 400) {
      await batch.commit();
      batchesCommitted += 1;
      batch = db.batch();
      writesInBatch = 0;
    }
  }

  if (writesInBatch > 0) {
    await batch.commit();
    batchesCommitted += 1;
  }

  const stats = await recomputePublicStats();

  return {
    synced: snap.size,
    verifiedActive: count,
    batchesCommitted,
    stats
  };
});
