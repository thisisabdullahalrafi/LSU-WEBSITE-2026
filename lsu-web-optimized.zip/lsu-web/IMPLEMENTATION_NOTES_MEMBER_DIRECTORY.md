# Member directory and executive board updates

## Changes
- Homepage verified-member statistic counts only members with `verified: true` and `status: active`.
- Members Directory lists only verified, active members (including for administrators); pending/unverified accounts remain blocked from the directory and other members' profiles.
- Directory category filter exposes exactly `Executive`, `Alumni`, and `General`.
- Legacy records stored as `General Member` are displayed and filtered as `General` for backward compatibility.
- Removed the unverified-status filter from the directory because unverified records must never appear there.
- Executive Board renders only live, verified, active member records assigned to the `Executive` category and matching role. It no longer shows static roster names as if they were linked profiles.
- Admin member category selector offers `Executive`, `Alumni`, and `General`; Firebase role updates accept the new `General` category while retaining compatibility with existing `General Member` records.

## Deployment notes
- Deploy the updated static website files.
- Existing members whose category is `General Member` do not need immediate migration; the UI treats that legacy value as `General`.
- To populate the Executive Board, verify the member and assign the exact Executive Board role in Admin Panel, with category `Executive`. The member's linked profile is then used by the board and homepage President section.
- The existing sanitized `publicMembers` projection and Firestore privacy rules are retained. Pending/unverified members can read only their own member record under the existing rules.
